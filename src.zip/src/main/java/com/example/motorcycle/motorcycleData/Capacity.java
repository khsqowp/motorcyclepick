package com.example.motorcycle.motorcycleData;

public enum Capacity {
    UNDERBONE,      //언더본
    QUARTER,        //쿼터
    MIDDLE,         //미들
    LITER,          //리터
    OVERLITER       //오버리터
}
