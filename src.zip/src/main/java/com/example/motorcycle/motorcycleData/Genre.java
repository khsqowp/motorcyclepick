package com.example.motorcycle.motorcycleData;

public enum Genre {
    CLASSIC,        //클래식
    DUALSPORT,      //멀티퍼포즈
    NAKED,          //네이키드
    CRUISER,        //크루저
    TOURING,        //투어러
    SUPERSPORT,     //슈퍼스포츠
    SPORTTOURING,   //스포츠 투어러
    ADVENTURE,      //어드벤처
    SCRAMBLER,      //스크램블러
    CAFERACER,      //카페레이서
    ENDURO,         //엔듀로
    SCOOTER,        //스쿠터
    MINIBIKE,       //미니바이크
    ELECTRIC,       //전기 바이크
    TRIKE,          //삼륜 바이크
    STREETFIGHTER,  //스트리트파이터

}
