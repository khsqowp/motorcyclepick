package com.example.motorcycle.motorcycleData;

public enum Year {
    y2024,
    y2023,
    y2022,
    y2021,
    y2020,
    y2019,
    y2018,
    y2017,
    y2016,
    y2015,
    y2014,
    y2013,
    y2012
}
