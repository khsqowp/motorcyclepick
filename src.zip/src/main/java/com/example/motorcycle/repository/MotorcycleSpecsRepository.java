//package com.example.motorcycle.repository;
//
//import com.example.motorcycle.domain.MotorcycleSpecs;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface MotorcycleSpecsRepository extends JpaRepository<MotorcycleSpecs, Long> {
//}
