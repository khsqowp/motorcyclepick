//package com.example.motorcycle.repository;// JPA 기반 MotorcycleRepository 삭제
//// public interface MotorcycleRepository extends JpaRepository<Motorcycle, Long> {}
//
//import com.example.motorcycle.domain.*;
//import org.apache.ibatis.annotations.*;
//
//// MyBatis 매퍼 인터페이스 추가
//@Mapper
//public interface MotorcycleMapperAll {
//
//}
