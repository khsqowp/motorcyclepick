package com.example.motorcycle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MotorcycleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MotorcycleApplication.class, args);
	}

}
