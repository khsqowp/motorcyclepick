package com.example.motorcycle.dto;

public class DeleteMotorcycleDTO {
    private Long deleteId;

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }
}

