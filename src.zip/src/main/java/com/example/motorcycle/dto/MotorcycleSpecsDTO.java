package com.example.motorcycle.dto;

import lombok.Data;

@Data
public class MotorcycleSpecsDTO {
    private Long id;
    private String production;
}
